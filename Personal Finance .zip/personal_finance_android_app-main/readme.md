<p align="center">
<img src="screen_recording.gif" alt="Recording the screen." style="width:300px;"/>
</p>
